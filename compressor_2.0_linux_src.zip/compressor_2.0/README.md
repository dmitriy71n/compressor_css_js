# Compressor

A multi-functional tool for minifying, formatting, concatenating, and converting web assets (HTML, CSS, JS, SASS).

## Features

- Minify HTML, CSS, JS files into single-line formats (e.g., `file.min.css`).
- Format minified files back to readable formats (e.g., `file.fmt.css`).
- Convert SASS/SCSS files to CSS.
- Process combined HTML+CSS+JS files.
- Concatenate multiple CSS files alphabetically into one.
- Multilingual interface (Russian, English).

## Installation (Linux)

1. Ensure Qt6 development tools are installed.
2. Run the build script:
   ```bash
   cd compressor
   bash scripts/build-linux.sh